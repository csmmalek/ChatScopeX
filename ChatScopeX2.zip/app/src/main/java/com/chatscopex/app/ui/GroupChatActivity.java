package com.chatscopex.app.ui;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.chatscopex.app.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
import java.util.Map;

public class GroupChatActivity extends AppCompatActivity {

    private EditText etGroupMessage;
    private Button btnSendGroupMessage;
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private String groupId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_chat);

        groupId = getIntent().getStringExtra("groupId");
        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();

        etGroupMessage = findViewById(R.id.etGroupMessage);
        btnSendGroupMessage = findViewById(R.id.btnSendGroupMessage);

        if (groupId == null || groupId.isEmpty()) {
            Toast.makeText(this, "خطأ في معرف المجموعة", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        btnSendGroupMessage.setOnClickListener(v -> sendGroupMessage());
    }

    private void sendGroupMessage() {
        String messageText = etGroupMessage.getText().toString().trim();
        if (messageText.isEmpty()) return;

        if (mAuth.getCurrentUser() == null) return;
        String currentUserId = mAuth.getCurrentUser().getUid();

        Map<String, Object> messageMap = new HashMap<>();
        messageMap.put("senderId", currentUserId);
        messageMap.put("text", messageText);
        messageMap.put("type", "text");
        messageMap.put("createdAt", FieldValue.serverTimestamp());

        db.collection("groups").document(groupId)
                .collection("messages")
                .add(messageMap)
                .addOnSuccessListener(documentReference -> etGroupMessage.setText(""))
                .addOnFailureListener(e -> Toast.makeText(this, "فشل الإرسال: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }
}
