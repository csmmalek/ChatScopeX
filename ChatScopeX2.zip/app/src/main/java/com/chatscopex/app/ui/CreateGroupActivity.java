package com.chatscopex.app.ui;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.chatscopex.app.R;
import com.chatscopex.app.model.GroupModel;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.ArrayList;
import java.util.List;

public class CreateGroupActivity extends AppCompatActivity {

    private EditText etGroupName, etMembers;
    private Button btnCreateGroup;
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_group);

        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();

        etGroupName = findViewById(R.id.etGroupName);
        etMembers = findViewById(R.id.etMembers);
        btnCreateGroup = findViewById(R.id.btnCreateGroup);

        btnCreateGroup.setOnClickListener(v -> createGroup());
    }

    private void createGroup() {
        String groupName = etGroupName.getText().toString().trim();
        String membersInput = etMembers.getText().toString().trim();

        if (groupName.isEmpty()) {
            etGroupName.setError("الرجاء إدخال اسم المجموعة");
            return;
        }

        if (mAuth.getCurrentUser() == null) return;

        String currentUserId = mAuth.getCurrentUser().getUid();
        String groupId = db.collection("groups").document().getId();

        List<String> members = new ArrayList<>();
        members.add(currentUserId);

        if (!membersInput.isEmpty()) {
            String[] splitMembers = membersInput.split(",");
            for (String memberId : splitMembers) {
                String trimmedId = memberId.trim();
                if (!trimmedId.isEmpty() && !members.contains(trimmedId)) {
                    members.add(trimmedId);
                }
            }
        }

        List<String> admins = new ArrayList<>();
        admins.add(currentUserId);

        GroupModel groupModel = new GroupModel(
                groupId,
                groupName,
                currentUserId,
                admins,
                members,
                System.currentTimeMillis()
        );

        db.collection("groups").document(groupId)
                .set(groupModel)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, "تم إنشاء المجموعة بنجاح", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .addOnFailureListener(e -> Toast.makeText(this, "خطأ في الإنشاء: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }
}
