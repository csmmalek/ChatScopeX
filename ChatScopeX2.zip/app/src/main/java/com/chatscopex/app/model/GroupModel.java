package com.chatscopex.app.model;

import java.util.List;

public class GroupModel {
    private String groupId;
    private String name;
    private String createdBy;
    private List<String> admins;
    private List<String> members;
    private long createdAt;

    public GroupModel() {}

    public GroupModel(String groupId, String name, String createdBy, List<String> admins, List<String> members, long createdAt) {
        this.groupId = groupId;
        this.name = name;
        this.createdBy = createdBy;
        this.admins = admins;
        this.members = members;
        this.createdAt = createdAt;
    }

    public String getGroupId() { return groupId; }
    public void setGroupId(String groupId) { this.groupId = groupId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getCreatedBy() { return createdBy; }
    public void setCreatedBy(String createdBy) { this.createdBy = createdBy; }
    public List<String> getAdmins() { return admins; }
    public void setAdmins(List<String> admins) { this.admins = admins; }
    public List<String> getMembers() { return members; }
    public void setMembers(List<String> members) { this.members = members; }
    public long getCreatedAt() { return createdAt; }
    public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }
}
