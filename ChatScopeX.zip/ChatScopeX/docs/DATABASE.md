# Firestore schema (phases 1–3)

| Collection | Document id | Fields | Who can read / write |
|---|---|---|---|
| `users` | `uid` | `displayName`, `displayNameLower`, `username`, `usernameLower`, `createdAt`, `updatedAt` | Read: any signed-in user (pages ≤ 50). Write: owner only, validated fields. No email is stored. |
| `usernames` | lowercase username | `uid` | `get` for signed-in users (no listing). Create only if the doc doesn't exist and the same batch sets `users/{uid}.usernameLower` to this name. |
| `chats` | `<uidA>_<uidB>` (uids sorted) | `members[2]`, `type="direct"`, `lastMessageText`, `lastMessageSenderId`, `lastMessageAt`, `lastRead{uid: timestamp}` | Members only. Members can change the preview (as sender) or **only their own** `lastRead` entry. |
| `chats/{id}/messages` | client-generated id | `senderId`, `text` (1–4000), `type="text"`, `createdAt` (server time) | Members read/create. `senderId` must equal the caller. No edit/delete. |

## Relations
- `chatId` is derived from the two uids → membership can be checked from the id alone, even before the chat doc exists.
- The chat doc is created together with the first message (one batch).
- `lastRead[uid]` drives the read ticks (✓ sent, ✓✓ read). "Delivered" is not implemented.

## Indexes (`firestore.indexes.json`)
- `chats`: `members` (array-contains) + `lastMessageAt` (desc) — chat list.
- Everything else uses automatic single-field indexes (messages by `createdAt`, user prefix search).

## What the client alone cannot guarantee
- Username uniqueness **is** enforced by rules (registry doc + same-batch check), but a user who deletes their account/data elsewhere could leave an orphan name; cleanup needs a backend job.
- Any signed-in user can search public profiles. If that is too open, move search to a backend function.
- Messages are stored as plain text (no E2EE yet) → anyone with Firebase project access can read them.

## Planned (not built)
`groups`, `channels`, `statuses` (use a Firestore TTL policy on `expireAt`), `blocks`, `devices` (FCM tokens), `keys` (public E2EE key bundles).

## Added in stage 5: statuses & groups/channels

| Collection | Document id | Fields | Who can read / write |
|---|---|---|---|
| `statuses` | auto-id | `uid`, `text` (1-280), `createdAt`, `expiresAt` (createdAt + 24h, enforced by rules) | Any signed-in user can read (no per-contact privacy list yet). Only the author can create/delete their own. |
| `groups` | auto-id | `name`, `type` ("group"\|"channel"), `members[]`, `admins[]` (subset of members), `createdBy`, `createdAt`, `lastMessage*` | Members only. Only an admin may change `members`/`admins` (except a member leaving, which only removes themselves). |
| `groups/{id}/messages` | client-generated id | same shape as `chats/{id}/messages` | Members read. Create: any member in a `group`; **admins only** in a `channel`. |

### Status TTL (manual one-time setup)
`expiresAt` only makes the app *hide* an expired status; the document is not deleted by itself. Firestore can delete it for you via a **TTL policy** on the `expiresAt` field:
Console → Firestore Database → **TTL** (or `gcloud firestore fields ttls update expiresAt --collection-group=statuses --enable-ttl`). Deletion typically happens within ~24h after expiry, not instantly.

### Known gaps (stage 5)
- No per-status privacy (visible to all signed-in users).
- "Add members" after a group/channel is created is not wired in the UI yet (the rules already allow it for an admin).
- No read receipts in group chats (ticks only exist in 1:1 chats).
- Group/channel photos need Storage (blocked on Blaze, see README).
