# Firestore schema (phases 1–3)

| Collection | Document id | Fields | Who can read / write |
|---|---|---|---|
| `users` | `uid` | `displayName`, `displayNameLower`, `username`, `usernameLower`, `createdAt`, `updatedAt` | Read: any signed-in user (pages ≤ 50). Write: owner only, validated fields. No email is stored. |
| `usernames` | lowercase username | `uid` | `get` for signed-in users (no listing). Create only if the doc doesn't exist and the same batch sets `users/{uid}.usernameLower` to this name. |
| `chats` | `<uidA>_<uidB>` (uids sorted) | `members[2]`, `type="direct"`, `lastMessageText`, `lastMessageSenderId`, `lastMessageAt`, `lastRead{uid: timestamp}` | Members only. Members can change the preview (as sender) or **only their own** `lastRead` entry. |
| `chats/{id}/messages` | client-generated id | `senderId`, `text` (1–4000), `type="text"`, `createdAt` (server time) | Members read/create. `senderId` must equal the caller. No edit/delete. |

## Relations
- `chatId` is derived from the two uids → membership can be checked from the id alone, even before the chat doc exists.
- The chat doc is created together with the first message (one batch).
- `lastRead[uid]` drives the read ticks (✓ sent, ✓✓ read). "Delivered" is not implemented.

## Indexes (`firestore.indexes.json`)
- `chats`: `members` (array-contains) + `lastMessageAt` (desc) — chat list.
- Everything else uses automatic single-field indexes (messages by `createdAt`, user prefix search).

## What the client alone cannot guarantee
- Username uniqueness **is** enforced by rules (registry doc + same-batch check), but a user who deletes their account/data elsewhere could leave an orphan name; cleanup needs a backend job.
- Any signed-in user can search public profiles. If that is too open, move search to a backend function.
- Messages are stored as plain text (no E2EE yet) → anyone with Firebase project access can read them.

## Planned (not built)
`groups`, `channels`, `statuses` (use a Firestore TTL policy on `expireAt`), `blocks`, `devices` (FCM tokens), `keys` (public E2EE key bundles).
