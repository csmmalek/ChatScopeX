package com.chatscopex.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.chatscopex.app.R;
import com.chatscopex.app.model.GroupSummary;
import com.chatscopex.app.util.ErrorMapper;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.List;

/** Needs the composite index in firestore.indexes.json for "groups" (members array-contains + lastMessageAt desc). */
public class GroupsFragment extends Fragment {
    private String myUid;
    private GroupsAdapter adapter;
    private ListenerRegistration reg;
    private ProgressBar progress;
    private TextView empty, error;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle s) {
        View v = inflater.inflate(R.layout.fragment_groups, container, false);
        FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
        myUid = u == null ? "" : u.getUid();

        progress = v.findViewById(R.id.progress);
        empty = v.findViewById(R.id.empty);
        error = v.findViewById(R.id.error);
        RecyclerView list = v.findViewById(R.id.list);
        list.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new GroupsAdapter(myUid, group -> startActivity(
                new Intent(requireContext(), GroupChatActivity.class)
                        .putExtra(GroupChatActivity.EXTRA_GROUP_ID, group.id)
                        .putExtra(GroupChatActivity.EXTRA_GROUP_NAME, group.name)));
        list.setAdapter(adapter);

        FloatingActionButton fab = v.findViewById(R.id.fab);
        fab.setOnClickListener(x -> {
            android.widget.PopupMenu menu = new android.widget.PopupMenu(requireContext(), fab);
            menu.getMenu().add(0, 1, 0, R.string.new_group);
            menu.getMenu().add(0, 2, 1, R.string.new_channel);
            menu.setOnMenuItemClickListener(item -> {
                startActivity(new Intent(requireContext(), CreateGroupActivity.class)
                        .putExtra(CreateGroupActivity.EXTRA_CHANNEL, item.getItemId() == 2));
                return true;
            });
            menu.show();
        });
        return v;
    }

    @Override
    public void onStart() {
        super.onStart();
        if (myUid.isEmpty()) return;
        Query q = FirebaseFirestore.getInstance().collection("groups")
                .whereArrayContains("members", myUid)
                .orderBy("lastMessageAt", Query.Direction.DESCENDING)
                .limit(50);
        reg = q.addSnapshotListener((snap, e) -> {
            if (!isAdded()) return;
            progress.setVisibility(View.GONE);
            if (e != null) {
                error.setText(ErrorMapper.res(e));
                error.setVisibility(View.VISIBLE);
                return;
            }
            error.setVisibility(View.GONE);
            List<GroupSummary> out = new ArrayList<>();
            for (DocumentSnapshot d : snap.getDocuments()) out.add(GroupSummary.from(d));
            adapter.submit(out);
            empty.setVisibility(out.isEmpty() ? View.VISIBLE : View.GONE);
        });
    }

    @Override
    public void onStop() {
        super.onStop();
        if (reg != null) { reg.remove(); reg = null; }
    }
}
