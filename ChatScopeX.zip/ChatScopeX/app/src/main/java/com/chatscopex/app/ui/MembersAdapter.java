package com.chatscopex.app.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.chatscopex.app.R;
import com.chatscopex.app.model.UserProfile;
import com.chatscopex.app.util.Avatars;
import com.chatscopex.app.util.ProfileCache;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/** Member row with an admin badge and an optional overflow menu (shown only to admins, and never on yourself). */
public class MembersAdapter extends RecyclerView.Adapter<MembersAdapter.VH> {
    public interface Listener { void onMenu(String uid, View anchor); }

    private final String myUid;
    private final boolean iAmAdmin;
    private final Listener listener;
    private List<String> uids = new ArrayList<>();
    private Set<String> admins = java.util.Collections.emptySet();

    public MembersAdapter(String myUid, boolean iAmAdmin, Listener listener) {
        this.myUid = myUid;
        this.iAmAdmin = iAmAdmin;
        this.listener = listener;
    }

    public void submit(List<String> uids, Set<String> admins) {
        this.uids = uids;
        this.admins = admins;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_member, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        String uid = uids.get(position);
        UserProfile p = ProfileCache.peek(uid);
        String name = p != null ? p.displayName : h.itemView.getContext().getString(R.string.unknown_user);
        h.name.setText(name);
        Avatars.setInitial(h.avatar, name);
        if (p == null) {
            ProfileCache.load(uid, loaded -> {
                int pos = h.getBindingAdapterPosition();
                if (pos != RecyclerView.NO_POSITION && uids.get(pos).equals(uid)) notifyItemChanged(pos);
            });
        }
        boolean isAdmin = admins.contains(uid);
        h.badge.setVisibility(isAdmin ? View.VISIBLE : View.GONE);
        boolean showMenu = iAmAdmin && !uid.equals(myUid);
        h.menu.setVisibility(showMenu ? View.VISIBLE : View.GONE);
        h.menu.setOnClickListener(v -> listener.onMenu(uid, v));
    }

    @Override
    public int getItemCount() { return uids.size(); }

    static class VH extends RecyclerView.ViewHolder {
        final TextView avatar, name, badge;
        final View menu;
        VH(@NonNull View v) {
            super(v);
            avatar = v.findViewById(R.id.avatar);
            name = v.findViewById(R.id.name);
            badge = v.findViewById(R.id.badge);
            badge.setText(R.string.admin_badge);
            menu = v.findViewById(R.id.menu);
        }
    }
}
