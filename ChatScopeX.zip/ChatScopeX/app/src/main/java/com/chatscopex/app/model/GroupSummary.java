package com.chatscopex.app.model;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

/** Row in the groups list, built from groups/{groupId}. "channel" = only admins can post (also checked in rules). */
public class GroupSummary {
    public final String id;
    public final String name;
    public final String type; // "group" | "channel"
    public final List<String> members;
    public final List<String> admins;
    public final String lastMessageText;
    public final String lastMessageSenderId;
    public final long lastMessageAtMillis;

    private GroupSummary(String id, String name, String type, List<String> members, List<String> admins,
                          String lastMessageText, String lastMessageSenderId, long lastMessageAtMillis) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.members = members;
        this.admins = admins;
        this.lastMessageText = lastMessageText;
        this.lastMessageSenderId = lastMessageSenderId;
        this.lastMessageAtMillis = lastMessageAtMillis;
    }

    @SuppressWarnings("unchecked")
    public static GroupSummary from(DocumentSnapshot d) {
        String name = d.getString("name");
        String type = d.getString("type");
        List<String> members = new ArrayList<>();
        Object m = d.get("members");
        if (m instanceof List) for (Object o : (List<Object>) m) if (o instanceof String) members.add((String) o);
        List<String> admins = new ArrayList<>();
        Object a = d.get("admins");
        if (a instanceof List) for (Object o : (List<Object>) a) if (o instanceof String) admins.add((String) o);

        Timestamp ts = d.getTimestamp("lastMessageAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE);
        String sender = d.getString("lastMessageSenderId");
        String text = d.getString("lastMessageText");
        return new GroupSummary(d.getId(), name == null ? "" : name, type == null ? "group" : type,
                members, admins, text == null ? "" : text, sender == null ? "" : sender,
                ts == null ? 0 : ts.toDate().getTime());
    }

    public boolean isChannel() { return "channel".equals(type); }
    public boolean isAdmin(String uid) { return admins.contains(uid); }
}
