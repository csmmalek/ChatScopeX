package com.chatscopex.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.chatscopex.app.R;
import com.chatscopex.app.model.UserProfile;
import com.chatscopex.app.util.ErrorMapper;
import com.chatscopex.app.util.ProfileCache;
import com.chatscopex.app.util.Ui;
import com.chatscopex.app.util.Validators;
import com.google.android.gms.tasks.Tasks;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Creates a group ("members" can all post) or a channel ("members" read-only, "admins" can post).
 * EXTRA_CHANNEL on the intent decides which; the creator is always the first admin.
 */
public class CreateGroupActivity extends AppCompatActivity {
    public static final String EXTRA_CHANNEL = "channel";
    private static final int LIMIT = 20;

    private boolean channel;
    private String myUid;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable pendingSearch;
    private int requestId = 0;

    private TextInputLayout nameLayout;
    private TextInputEditText nameEt, queryEt;
    private TextView selectedCount;
    private CheckableUsersAdapter adapter;
    private Button submit;
    private ProgressBar progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
        if (u == null) { finish(); return; }
        myUid = u.getUid();
        channel = getIntent().getBooleanExtra(EXTRA_CHANNEL, false);

        setContentView(R.layout.activity_create_group);
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());
        toolbar.setTitle(channel ? R.string.new_channel : R.string.new_group);

        nameLayout = findViewById(R.id.name_layout);
        nameLayout.setHint(getString(channel ? R.string.channel_name : R.string.group_name));
        nameEt = findViewById(R.id.name);
        queryEt = findViewById(R.id.query);
        selectedCount = findViewById(R.id.selected_count);
        selectedCount.setText(getString(R.string.selected_count, 0));
        submit = findViewById(R.id.submit);
        submit.setText(R.string.create);
        progress = findViewById(R.id.progress);

        RecyclerView list = findViewById(R.id.list);
        list.setLayoutManager(new LinearLayoutManager(this));
        adapter = new CheckableUsersAdapter(count -> selectedCount.setText(getString(R.string.selected_count, count)));
        list.setAdapter(adapter);

        queryEt.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) {
                if (pendingSearch != null) handler.removeCallbacks(pendingSearch);
                final String q = s.toString();
                pendingSearch = () -> search(q);
                handler.postDelayed(pendingSearch, 400);
            }
        });

        submit.setOnClickListener(v -> create());
    }

    private void search(String raw) {
        String n = raw.trim();
        if (n.startsWith("@")) n = n.substring(1);
        n = n.toLowerCase(Locale.ROOT);
        if (n.length() < 2) { adapter.submit(new ArrayList<>()); return; }
        final int rid = ++requestId;

        FirebaseFirestore db = FirebaseFirestore.getInstance();
        Query byUsername = db.collection("users")
                .whereGreaterThanOrEqualTo("usernameLower", n)
                .whereLessThanOrEqualTo("usernameLower", n + "\uf8ff").limit(LIMIT);
        Query byName = db.collection("users")
                .whereGreaterThanOrEqualTo("displayNameLower", n)
                .whereLessThanOrEqualTo("displayNameLower", n + "\uf8ff").limit(LIMIT);

        Tasks.whenAllSuccess(byUsername.get(), byName.get()).addOnSuccessListener(results -> {
            if (rid != requestId) return;
            Map<String, UserProfile> merged = new LinkedHashMap<>();
            for (Object o : results) {
                for (DocumentSnapshot d : ((QuerySnapshot) o).getDocuments()) {
                    if (d.getId().equals(myUid)) continue;
                    UserProfile p = UserProfile.from(d);
                    ProfileCache.put(p);
                    merged.put(d.getId(), p);
                }
            }
            adapter.submit(new ArrayList<>(merged.values()));
        });
    }

    private void create() {
        nameLayout.setError(null);
        String name = nameEt.getText() == null ? "" : nameEt.getText().toString().trim();
        List<String> picked = adapter.selectedUids();

        boolean ok = true;
        if (!Validators.isDisplayName(name)) {
            nameLayout.setError(getString(R.string.err_group_name));
            ok = false;
        }
        if (picked.isEmpty()) {
            Ui.snack(this, R.string.err_select_members);
            ok = false;
        }
        if (!ok) return;

        submit.setEnabled(false);
        progress.setVisibility(View.VISIBLE);

        List<String> members = new ArrayList<>(picked);
        members.add(myUid);

        Map<String, Object> data = new HashMap<>();
        data.put("name", name);
        data.put("type", channel ? "channel" : "group");
        data.put("members", members);
        data.put("admins", Arrays.asList(myUid)); // creator is the only admin at first
        data.put("createdBy", myUid);
        data.put("createdAt", FieldValue.serverTimestamp());
        data.put("lastMessageText", "");
        data.put("lastMessageSenderId", "");
        data.put("lastMessageAt", FieldValue.serverTimestamp());

        FirebaseFirestore.getInstance().collection("groups").add(data)
                .addOnSuccessListener(doc -> {
                    Intent i = new Intent(this, GroupChatActivity.class)
                            .putExtra(GroupChatActivity.EXTRA_GROUP_ID, doc.getId())
                            .putExtra(GroupChatActivity.EXTRA_GROUP_NAME, name);
                    startActivity(i);
                    finish();
                })
                .addOnFailureListener(e -> {
                    submit.setEnabled(true);
                    progress.setVisibility(View.GONE);
                    Ui.snack(this, ErrorMapper.res(e));
                });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (pendingSearch != null) handler.removeCallbacks(pendingSearch);
    }
}
