package com.chatscopex.app.util;

import android.widget.TextView;

public final class Avatars {
    private Avatars() {}

    /** Shows the first letter of the name in the round avatar view (profile photos arrive in phase 4). */
    public static void setInitial(TextView v, String name) {
        if (name == null || name.trim().isEmpty()) {
            v.setText("?");
            return;
        }
        String n = name.trim();
        v.setText(n.substring(0, n.offsetByCodePoints(0, 1)).toUpperCase());
    }
}
