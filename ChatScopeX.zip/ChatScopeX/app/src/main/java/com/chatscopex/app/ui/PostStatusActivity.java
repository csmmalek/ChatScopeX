package com.chatscopex.app.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;

import androidx.appcompat.app.AppCompatActivity;

import com.chatscopex.app.R;
import com.chatscopex.app.util.ErrorMapper;
import com.chatscopex.app.util.Ui;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/** Posts a text-only status that expires 24h later. Image/video status needs Storage (not enabled yet). */
public class PostStatusActivity extends AppCompatActivity {
    private static final long DAY_MS = 24L * 60 * 60 * 1000;

    private TextInputEditText text;
    private Button submit;
    private ProgressBar progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_status);
        ((MaterialToolbar) findViewById(R.id.toolbar)).setNavigationOnClickListener(v -> finish());
        text = findViewById(R.id.text);
        submit = findViewById(R.id.submit);
        progress = findViewById(R.id.progress);
        submit.setOnClickListener(v -> post());
    }

    private void post() {
        FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
        if (u == null) { finish(); return; }
        String body = text.getText() == null ? "" : text.getText().toString().trim();
        if (body.isEmpty()) return;

        submit.setEnabled(false);
        progress.setVisibility(View.VISIBLE);

        // expiresAt is computed on the client (serverTimestamp can't be offset by a client-side duration),
        // so a user with a badly wrong device clock may see their status expire a bit early or late.
        long expiresAtMillis = System.currentTimeMillis() + DAY_MS;
        Map<String, Object> data = new HashMap<>();
        data.put("uid", u.getUid());
        data.put("text", body);
        data.put("createdAt", FieldValue.serverTimestamp());
        data.put("expiresAt", new Timestamp(new Date(expiresAtMillis)));

        FirebaseFirestore.getInstance().collection("statuses").add(data)
                .addOnSuccessListener(doc -> finish())
                .addOnFailureListener(e -> {
                    submit.setEnabled(true);
                    progress.setVisibility(View.GONE);
                    Ui.snack(this, ErrorMapper.res(e));
                });
    }
}
