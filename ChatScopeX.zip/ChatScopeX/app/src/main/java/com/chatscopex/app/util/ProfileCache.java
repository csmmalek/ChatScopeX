package com.chatscopex.app.util;

import com.chatscopex.app.model.UserProfile;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

/** In-memory cache of public profiles. Main-thread only (Firestore callbacks run on the main thread). */
public final class ProfileCache {
    public interface Callback { void onLoaded(UserProfile profile); }

    private static final Map<String, UserProfile> CACHE = new HashMap<>();

    private ProfileCache() {}

    public static UserProfile peek(String uid) { return CACHE.get(uid); }

    public static void put(UserProfile p) { CACHE.put(p.uid, p); }

    public static void clear() { CACHE.clear(); }

    public static void load(String uid, Callback cb) {
        UserProfile cached = CACHE.get(uid);
        if (cached != null) { cb.onLoaded(cached); return; }
        FirebaseFirestore.getInstance().collection("users").document(uid).get()
                .addOnSuccessListener(d -> {
                    if (d.exists()) {
                        UserProfile p = UserProfile.from(d);
                        CACHE.put(uid, p);
                        cb.onLoaded(p);
                    }
                });
        // Failures are ignored on purpose: callers show a placeholder name and can retry later.
    }
}
