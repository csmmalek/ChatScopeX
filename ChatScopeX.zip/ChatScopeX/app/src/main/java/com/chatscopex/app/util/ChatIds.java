package com.chatscopex.app.util;

/**
 * Deterministic id for a 1:1 chat: the two uids sorted, joined by "_".
 * firestore.rules relies on this format to decide membership, so do not change it on one side only.
 */
public final class ChatIds {
    private ChatIds() {}

    public static String direct(String a, String b) {
        return a.compareTo(b) < 0 ? a + "_" + b : b + "_" + a;
    }
}
