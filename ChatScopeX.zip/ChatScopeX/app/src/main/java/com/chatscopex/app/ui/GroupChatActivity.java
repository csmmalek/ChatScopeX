package com.chatscopex.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.chatscopex.app.R;
import com.chatscopex.app.model.GroupSummary;
import com.chatscopex.app.model.Message;
import com.chatscopex.app.util.ErrorMapper;
import com.chatscopex.app.util.Ui;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.MetadataChanges;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.WriteBatch;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Group / channel chat. Same message shape and paging approach as ChatActivity (see its comment).
 * No read receipts here yet (per-member read state for N members needs more design) -> ticks are not shown.
 */
public class GroupChatActivity extends AppCompatActivity {
    public static final String EXTRA_GROUP_ID = "group_id";
    public static final String EXTRA_GROUP_NAME = "group_name";
    private static final int PAGE = 30;
    private static final int PREVIEW_MAX = 100;

    private FirebaseFirestore db;
    private String myUid, groupId;
    private DocumentReference groupRef;
    private boolean isChannel = false;

    private RecyclerView list;
    private LinearLayoutManager lm;
    private MessagesAdapter adapter;
    private TextView emptyView, readonlyNote;
    private View inputRow;
    private TextInputEditText input;

    private final Map<String, Message> all = new HashMap<>();
    private final Map<String, Message> failed = new LinkedHashMap<>();
    private DocumentSnapshot oldest;
    private boolean pageStateKnown = false, hasMore = true, loadingOlder = false;

    private ListenerRegistration msgReg, groupReg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
        groupId = getIntent().getStringExtra(EXTRA_GROUP_ID);
        if (u == null || groupId == null) { finish(); return; }
        myUid = u.getUid();
        db = FirebaseFirestore.getInstance();
        groupRef = db.collection("groups").document(groupId);

        setContentView(R.layout.activity_group_chat);
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());
        String name = getIntent().getStringExtra(EXTRA_GROUP_NAME);
        if (name != null) toolbar.setTitle(name);
        toolbar.setOnClickListener(v -> startActivity(
                new Intent(this, GroupInfoActivity.class).putExtra(GroupInfoActivity.EXTRA_GROUP_ID, groupId)));

        emptyView = findViewById(R.id.empty);
        readonlyNote = findViewById(R.id.readonly_note);
        inputRow = findViewById(R.id.input_row);
        input = findViewById(R.id.input);
        list = findViewById(R.id.list);
        lm = new LinearLayoutManager(this);
        lm.setStackFromEnd(true);
        list.setLayoutManager(lm);
        adapter = new MessagesAdapter(myUid, this::retry);
        list.setAdapter(adapter);
        list.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override public void onScrolled(RecyclerView rv, int dx, int dy) {
                if (dy < 0 && lm.findFirstVisibleItemPosition() <= 2) loadOlder();
            }
        });

        ImageButton send = findViewById(R.id.send);
        send.setOnClickListener(v -> onSendClicked());
    }

    @Override
    protected void onStart() {
        super.onStart();
        groupReg = groupRef.addSnapshotListener((snap, e) -> {
            if (e != null || snap == null || !snap.exists()) return;
            GroupSummary g = GroupSummary.from(snap);
            isChannel = g.isChannel();
            boolean canPost = !isChannel || g.isAdmin(myUid);
            inputRow.setVisibility(canPost ? View.VISIBLE : View.GONE);
            readonlyNote.setVisibility(isChannel && !canPost ? View.VISIBLE : View.GONE);
        });

        Query q = groupRef.collection("messages")
                .orderBy("createdAt", Query.Direction.DESCENDING).limit(PAGE);
        msgReg = q.addSnapshotListener(MetadataChanges.INCLUDE, (snap, e) -> {
            if (e != null) { Ui.snack(this, ErrorMapper.res(e)); return; }
            if (snap == null) return;
            if (!pageStateKnown && !snap.getMetadata().isFromCache()) {
                pageStateKnown = true;
                hasMore = snap.size() >= PAGE;
                java.util.List<DocumentSnapshot> docs = snap.getDocuments();
                for (int i = docs.size() - 1; i >= 0; i--) {
                    if (!docs.get(i).getMetadata().hasPendingWrites()) { oldest = docs.get(i); break; }
                }
            }
            for (DocumentChange ch : snap.getDocumentChanges(MetadataChanges.INCLUDE)) {
                if (ch.getType() == DocumentChange.Type.REMOVED) continue;
                DocumentSnapshot d = ch.getDocument();
                all.put(d.getId(), Message.from(d));
                failed.remove(d.getId());
            }
            render();
        });
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (msgReg != null) { msgReg.remove(); msgReg = null; }
        if (groupReg != null) { groupReg.remove(); groupReg = null; }
    }

    private void render() {
        ArrayList<Message> out = new ArrayList<>(all.values());
        out.addAll(failed.values());
        Collections.sort(out, (a, b) -> {
            int c = Long.compare(a.timeMillis, b.timeMillis);
            return c != 0 ? c : a.id.compareTo(b.id);
        });
        boolean nearBottom = lm.findLastVisibleItemPosition() >= adapter.getItemCount() - 2;
        boolean lastIsMine = !out.isEmpty() && out.get(out.size() - 1).senderId.equals(myUid);
        adapter.submit(out, 0); // no read receipts in groups yet, so otherReadMillis is unused (stays as "sent")
        if (!out.isEmpty() && (nearBottom || lastIsMine)) list.scrollToPosition(out.size() - 1);
        emptyView.setVisibility(out.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void loadOlder() {
        if (loadingOlder || !hasMore || oldest == null) return;
        loadingOlder = true;
        groupRef.collection("messages")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .startAfter(oldest).limit(PAGE).get()
                .addOnSuccessListener(qs -> {
                    loadingOlder = false;
                    int before = all.size();
                    java.util.List<DocumentSnapshot> docs = qs.getDocuments();
                    for (DocumentSnapshot d : docs) all.put(d.getId(), Message.from(d));
                    if (!docs.isEmpty()) oldest = docs.get(docs.size() - 1);
                    hasMore = docs.size() >= PAGE;
                    int added = all.size() - before;
                    render();
                    if (added > 0) lm.scrollToPositionWithOffset(added, 0);
                })
                .addOnFailureListener(e -> { loadingOlder = false; Ui.snack(this, ErrorMapper.res(e)); });
    }

    private void onSendClicked() {
        String text = input.getText() == null ? "" : input.getText().toString().trim();
        if (text.isEmpty()) return;
        input.setText("");
        String id = groupRef.collection("messages").document().getId();
        send(id, text, System.currentTimeMillis());
    }

    private void retry(Message m) {
        failed.remove(m.id);
        render();
        send(m.id, m.text, m.timeMillis);
    }

    private void send(String id, String text, long localTime) {
        DocumentReference msgRef = groupRef.collection("messages").document(id);
        Map<String, Object> msg = new HashMap<>();
        msg.put("senderId", myUid);
        msg.put("text", text);
        msg.put("type", "text");
        msg.put("createdAt", FieldValue.serverTimestamp());

        Map<String, Object> group = new HashMap<>();
        group.put("lastMessageText", text.length() > PREVIEW_MAX ? text.substring(0, PREVIEW_MAX) : text);
        group.put("lastMessageSenderId", myUid);
        group.put("lastMessageAt", FieldValue.serverTimestamp());

        WriteBatch b = db.batch();
        b.update(groupRef, group); // group already exists (created in CreateGroupActivity), unlike direct chats
        b.set(msgRef, msg);
        b.commit().addOnFailureListener(e -> {
            all.remove(id);
            failed.put(id, new Message(id, myUid, text, localTime, false, true));
            render();
            Ui.snack(this, ErrorMapper.res(e));
        });
    }
}
