package com.chatscopex.app.model;

import com.google.firebase.firestore.DocumentSnapshot;

/** Public profile stored in users/{uid}. Contains no email and no secrets. */
public class UserProfile {
    public final String uid;
    public final String displayName;
    public final String username;

    public UserProfile(String uid, String displayName, String username) {
        this.uid = uid;
        this.displayName = displayName;
        this.username = username;
    }

    public static UserProfile from(DocumentSnapshot d) {
        String name = d.getString("displayName");
        String un = d.getString("username");
        return new UserProfile(d.getId(), name == null ? "" : name, un == null ? "" : un);
    }
}
