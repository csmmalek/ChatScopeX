package com.chatscopex.app.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.chatscopex.app.R;
import com.google.android.material.appbar.MaterialToolbar;

/** Honest "not implemented yet" screen: no fake data, no dead buttons. */
public class PlaceholderFragment extends Fragment {
    private static final String ARG_TITLE = "title";
    private static final String ARG_BODY = "body";

    public static PlaceholderFragment newInstance(int titleRes, int bodyRes) {
        PlaceholderFragment f = new PlaceholderFragment();
        Bundle b = new Bundle();
        b.putInt(ARG_TITLE, titleRes);
        b.putInt(ARG_BODY, bodyRes);
        f.setArguments(b);
        return f;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle s) {
        View v = inflater.inflate(R.layout.fragment_placeholder, container, false);
        Bundle a = requireArguments();
        ((MaterialToolbar) v.findViewById(R.id.toolbar)).setTitle(a.getInt(ARG_TITLE));
        ((TextView) v.findViewById(R.id.body)).setText(a.getInt(ARG_BODY));
        return v;
    }
}
