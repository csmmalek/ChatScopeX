package com.chatscopex.app.util;

import android.content.Context;

import com.chatscopex.app.R;

/** Short "x minutes/hours ago" label used for statuses. Messages elsewhere use TimeFormat (clock time). */
public final class RelativeTime {
    private RelativeTime() {}

    public static String ago(Context c, long millis) {
        if (millis <= 0) return "";
        long diff = System.currentTimeMillis() - millis;
        long minutes = diff / 60000;
        if (minutes < 60) return c.getString(R.string.ago_minutes, Math.max(0, minutes));
        long hours = minutes / 60;
        return c.getString(R.string.ago_hours, hours);
    }
}
