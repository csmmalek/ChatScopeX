package com.chatscopex.app.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.chatscopex.app.R;
import com.chatscopex.app.model.Status;
import com.chatscopex.app.model.UserProfile;
import com.chatscopex.app.util.Avatars;
import com.chatscopex.app.util.ProfileCache;
import com.chatscopex.app.util.RelativeTime;

import java.util.ArrayList;
import java.util.List;

/** One row per user who currently has an active status (their most recent one). */
public class StatusAdapter extends RecyclerView.Adapter<StatusAdapter.VH> {
    public interface Listener { void onOpen(Status status, String name); }

    private final Listener listener;
    private List<Status> items = new ArrayList<>();

    public StatusAdapter(Listener listener) { this.listener = listener; }

    public void submit(List<Status> list) {
        items = list;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_status_user, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        Context c = h.itemView.getContext();
        Status s = items.get(position);
        UserProfile p = ProfileCache.peek(s.uid);
        String name = p != null ? p.displayName : c.getString(R.string.unknown_user);
        h.name.setText(name);
        Avatars.setInitial(h.avatar, name);
        if (p == null) {
            ProfileCache.load(s.uid, loaded -> {
                int pos = h.getBindingAdapterPosition();
                if (pos != RecyclerView.NO_POSITION && items.get(pos).uid.equals(s.uid)) notifyItemChanged(pos);
            });
        }
        h.preview.setText(s.text);
        h.time.setText(RelativeTime.ago(c, s.createdAtMillis));
        h.itemView.setOnClickListener(v -> listener.onOpen(s, name));
    }

    @Override
    public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        final TextView avatar, name, preview, time;
        VH(@NonNull View v) {
            super(v);
            avatar = v.findViewById(R.id.avatar);
            name = v.findViewById(R.id.name);
            preview = v.findViewById(R.id.preview);
            time = v.findViewById(R.id.time);
        }
    }
}
