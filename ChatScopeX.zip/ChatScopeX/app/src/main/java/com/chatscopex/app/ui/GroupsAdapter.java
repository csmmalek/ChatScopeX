package com.chatscopex.app.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.chatscopex.app.R;
import com.chatscopex.app.model.GroupSummary;
import com.chatscopex.app.util.Avatars;
import com.chatscopex.app.util.TimeFormat;

import java.util.ArrayList;
import java.util.List;

public class GroupsAdapter extends RecyclerView.Adapter<GroupsAdapter.VH> {
    public interface Listener { void onOpen(GroupSummary group); }

    private final String myUid;
    private final Listener listener;
    private List<GroupSummary> items = new ArrayList<>();

    public GroupsAdapter(String myUid, Listener listener) {
        this.myUid = myUid;
        this.listener = listener;
    }

    public void submit(List<GroupSummary> list) {
        items = list;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_group, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        Context c = h.itemView.getContext();
        GroupSummary g = items.get(position);
        h.name.setText(g.name);
        Avatars.setInitial(h.avatar, g.name);
        String last = g.lastMessageText;
        if (!last.isEmpty() && g.lastMessageSenderId.equals(myUid)) last = c.getString(R.string.you_prefix, last);
        h.last.setText(last.isEmpty() ? c.getString(g.isChannel() ? R.string.channel_info : R.string.group_info) : last);
        h.time.setText(TimeFormat.format(c, g.lastMessageAtMillis));
        h.itemView.setOnClickListener(v -> listener.onOpen(g));
    }

    @Override
    public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        final TextView avatar, name, last, time;
        VH(@NonNull View v) {
            super(v);
            avatar = v.findViewById(R.id.avatar);
            name = v.findViewById(R.id.name);
            last = v.findViewById(R.id.last);
            time = v.findViewById(R.id.time);
        }
    }
}
