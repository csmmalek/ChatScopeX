package com.chatscopex.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.chatscopex.app.R;
import com.chatscopex.app.model.UserProfile;
import com.chatscopex.app.util.Avatars;
import com.chatscopex.app.util.ProfileCache;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

public class SettingsFragment extends Fragment {
    private TextView avatar, name, username;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle s) {
        View v = inflater.inflate(R.layout.fragment_settings, container, false);
        avatar = v.findViewById(R.id.avatar);
        name = v.findViewById(R.id.name);
        username = v.findViewById(R.id.username);
        Button editBtn = v.findViewById(R.id.edit_profile);
        Button signOut = v.findViewById(R.id.sign_out);

        editBtn.setOnClickListener(x -> startActivity(
                new Intent(requireContext(), ProfileSetupActivity.class)
                        .putExtra(ProfileSetupActivity.EXTRA_EDIT, true)));
        signOut.setOnClickListener(x -> signOut());
        return v;
    }

    @Override
    public void onResume() {
        super.onResume(); // also refreshes after returning from "edit profile"
        FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
        if (u == null) return;
        UserProfile cached = ProfileCache.peek(u.getUid());
        if (cached != null) show(cached);
        FirebaseFirestore.getInstance().collection("users").document(u.getUid()).get()
                .addOnSuccessListener(d -> {
                    if (!isAdded() || !d.exists()) return;
                    UserProfile p = UserProfile.from(d);
                    ProfileCache.put(p);
                    show(p);
                });
    }

    private void show(UserProfile p) {
        Avatars.setInitial(avatar, p.displayName);
        name.setText(p.displayName);
        username.setText("@" + p.username);
    }

    /** Signs out and wipes the local Firestore cache so the next account on this device cannot see it. */
    private void signOut() {
        FirebaseAuth.getInstance().signOut();
        ProfileCache.clear();
        final android.content.Context app = requireContext().getApplicationContext();
        final FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.terminate()
                .continueWithTask(t -> db.clearPersistence())
                .addOnCompleteListener(t -> {
                    Intent i = new Intent(app, LauncherActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    app.startActivity(i);
                });
    }
}
