package com.chatscopex.app.model;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentSnapshot;

/** A 24-hour text status. Image/video status is not implemented yet (needs Firebase Storage). */
public class Status {
    public final String id;
    public final String uid;
    public final String text;
    public final long createdAtMillis;
    public final long expiresAtMillis;

    public Status(String id, String uid, String text, long createdAtMillis, long expiresAtMillis) {
        this.id = id;
        this.uid = uid;
        this.text = text;
        this.createdAtMillis = createdAtMillis;
        this.expiresAtMillis = expiresAtMillis;
    }

    public static Status from(DocumentSnapshot d) {
        Timestamp created = d.getTimestamp("createdAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE);
        Timestamp expires = d.getTimestamp("expiresAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE);
        String uid = d.getString("uid");
        String text = d.getString("text");
        return new Status(d.getId(), uid == null ? "" : uid, text == null ? "" : text,
                created == null ? 0 : created.toDate().getTime(),
                expires == null ? 0 : expires.toDate().getTime());
    }
}
