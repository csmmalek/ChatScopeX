package com.chatscopex.app.ui;

import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.chatscopex.app.R;
import com.chatscopex.app.model.Message;
import com.chatscopex.app.util.TimeFormat;

import java.util.ArrayList;
import java.util.List;

public class MessagesAdapter extends RecyclerView.Adapter<MessagesAdapter.VH> {
    public interface RetryListener { void onRetry(Message m); }

    private final String myUid;
    private final RetryListener retry;
    private List<Message> items = new ArrayList<>();
    private long otherReadMillis = 0;

    public MessagesAdapter(String myUid, RetryListener retry) {
        this.myUid = myUid;
        this.retry = retry;
    }

    public void submit(List<Message> list, long otherReadMillis) {
        this.items = list;
        this.otherReadMillis = otherReadMillis;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_message, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        Context c = h.itemView.getContext();
        Message m = items.get(position);
        boolean mine = m.senderId.equals(myUid);

        // START/END follow the layout direction, so bubbles mirror correctly in RTL.
        h.root.setGravity(mine ? Gravity.END : Gravity.START);
        h.bubble.setBackgroundResource(mine ? R.drawable.bubble_out : R.drawable.bubble_in);
        int textColor = c.getColor(mine ? R.color.bubble_out_text : R.color.bubble_in_text);
        h.text.setTextColor(textColor);
        h.meta.setTextColor(textColor);
        h.text.setText(m.text);

        if (m.failed) {
            h.meta.setText(R.string.message_failed);
            h.meta.setTextColor(c.getColor(R.color.error_red));
            h.bubble.setOnClickListener(v -> retry.onRetry(m));
        } else {
            h.bubble.setOnClickListener(null);
            h.bubble.setClickable(false);
            String time = TimeFormat.format(c, m.timeMillis);
            if (mine) {
                // Only "sent" and "read" are tracked. "Delivered" would need a per-device receipt (not built).
                String tick = m.pending ? "\u23F3" : (m.timeMillis <= otherReadMillis ? "\u2713\u2713" : "\u2713");
                h.meta.setText(time + "  " + tick);
            } else {
                h.meta.setText(time);
            }
        }
    }

    @Override
    public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        final LinearLayout root, bubble;
        final TextView text, meta;

        VH(@NonNull View v) {
            super(v);
            root = v.findViewById(R.id.root);
            bubble = v.findViewById(R.id.bubble);
            text = v.findViewById(R.id.text);
            meta = v.findViewById(R.id.meta);
        }
    }
}
