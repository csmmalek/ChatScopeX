package com.chatscopex.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.chatscopex.app.R;
import com.chatscopex.app.model.UserProfile;
import com.chatscopex.app.util.ErrorMapper;
import com.chatscopex.app.util.ProfileCache;
import com.chatscopex.app.util.Ui;
import com.chatscopex.app.util.Validators;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.WriteBatch;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Create (first run) or edit the profile.
 * Username uniqueness: usernames/{lowercase} is claimed in the SAME batch as users/{uid};
 * firestore.rules reject the batch if that document already exists.
 */
public class ProfileSetupActivity extends AppCompatActivity {
    public static final String EXTRA_EDIT = "edit";

    private boolean edit;
    private String uid;
    private String oldUsernameLower;
    private FirebaseFirestore db;

    private TextInputLayout nameLayout, userLayout;
    private TextInputEditText nameEt, userEt;
    private Button save;
    private ProgressBar progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
        if (u == null) {
            startActivity(new Intent(this, LauncherActivity.class));
            finish();
            return;
        }
        uid = u.getUid();
        db = FirebaseFirestore.getInstance();
        edit = getIntent().getBooleanExtra(EXTRA_EDIT, false);

        setContentView(R.layout.activity_profile_setup);
        nameLayout = findViewById(R.id.name_layout);
        userLayout = findViewById(R.id.username_layout);
        nameEt = findViewById(R.id.name);
        userEt = findViewById(R.id.username);
        save = findViewById(R.id.save);
        progress = findViewById(R.id.progress);
        ((TextView) findViewById(R.id.title)).setText(edit ? R.string.edit_profile : R.string.profile_setup_title);
        save.setOnClickListener(v -> save());

        if (edit) loadExisting();
    }

    private void loadExisting() {
        setBusy(true);
        db.collection("users").document(uid).get().addOnSuccessListener(d -> {
            setBusy(false);
            UserProfile p = UserProfile.from(d);
            nameEt.setText(p.displayName);
            userEt.setText(p.username);
            oldUsernameLower = p.username.toLowerCase(Locale.ROOT);
        }).addOnFailureListener(e -> {
            setBusy(false);
            Ui.snack(this, ErrorMapper.res(e));
        });
    }

    private void setBusy(boolean busy) {
        progress.setVisibility(busy ? View.VISIBLE : View.GONE);
        save.setEnabled(!busy);
    }

    private void save() {
        nameLayout.setError(null);
        userLayout.setError(null);
        String name = nameEt.getText() == null ? "" : nameEt.getText().toString().trim();
        String username = userEt.getText() == null ? "" : userEt.getText().toString().trim();
        if (username.startsWith("@")) username = username.substring(1);

        boolean ok = true;
        if (!Validators.isDisplayName(name)) {
            nameLayout.setError(getString(R.string.err_name_length));
            ok = false;
        }
        if (!Validators.isUsername(username)) {
            userLayout.setError(getString(R.string.err_username_format));
            ok = false;
        }
        if (!ok) return;

        final String fName = name;
        final String fUser = username;
        final String lower = username.toLowerCase(Locale.ROOT);
        setBusy(true);

        if (edit && lower.equals(oldUsernameLower)) {
            commit(fName, fUser, lower, false);
            return;
        }
        // Friendly pre-check; the rules are what actually guarantee uniqueness (race-safe).
        db.collection("usernames").document(lower).get().addOnSuccessListener(d -> {
            if (d.exists() && !uid.equals(d.getString("uid"))) {
                setBusy(false);
                userLayout.setError(getString(R.string.err_username_taken));
            } else {
                commit(fName, fUser, lower, true);
            }
        }).addOnFailureListener(e -> {
            setBusy(false);
            Ui.snack(this, ErrorMapper.res(e));
        });
    }

    private void commit(String name, String username, String lower, boolean usernameChanged) {
        DocumentReference userRef = db.collection("users").document(uid);
        WriteBatch b = db.batch();

        Map<String, Object> data = new HashMap<>();
        data.put("displayName", name);
        data.put("displayNameLower", name.toLowerCase(Locale.ROOT));
        data.put("username", username);
        data.put("usernameLower", lower);
        data.put("updatedAt", FieldValue.serverTimestamp());

        if (edit) {
            b.update(userRef, data);
        } else {
            data.put("createdAt", FieldValue.serverTimestamp());
            b.set(userRef, data);
        }
        if (usernameChanged) {
            Map<String, Object> claim = new HashMap<>();
            claim.put("uid", uid);
            b.set(db.collection("usernames").document(lower), claim);
            if (edit && oldUsernameLower != null) {
                b.delete(db.collection("usernames").document(oldUsernameLower));
            }
        }

        b.commit().addOnSuccessListener(v -> {
            ProfileCache.put(new UserProfile(uid, name, username));
            if (edit) {
                finish();
            } else {
                Intent i = new Intent(this, MainActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i);
            }
        }).addOnFailureListener(e -> {
            setBusy(false);
            // PERMISSION_DENIED here almost always means the username was claimed by someone else meanwhile.
            if (usernameChanged && e instanceof FirebaseFirestoreException
                    && ((FirebaseFirestoreException) e).getCode() == FirebaseFirestoreException.Code.PERMISSION_DENIED) {
                userLayout.setError(getString(R.string.err_username_taken));
            } else {
                Ui.snack(this, ErrorMapper.res(e));
            }
        });
    }
}
