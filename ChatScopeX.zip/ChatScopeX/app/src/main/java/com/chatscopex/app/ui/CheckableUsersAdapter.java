package com.chatscopex.app.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.chatscopex.app.R;
import com.chatscopex.app.model.UserProfile;
import com.chatscopex.app.util.Avatars;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** User list with a toggle-select (used by "create group"). */
public class CheckableUsersAdapter extends RecyclerView.Adapter<CheckableUsersAdapter.VH> {
    public interface Listener { void onSelectionChanged(int count); }

    private final Listener listener;
    private final Set<String> selected = new LinkedHashSet<>();
    private List<UserProfile> items = new ArrayList<>();

    public CheckableUsersAdapter(Listener listener) { this.listener = listener; }

    public void submit(List<UserProfile> list) {
        items = list;
        notifyDataSetChanged();
    }

    public List<String> selectedUids() { return new ArrayList<>(selected); }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_user_checkable, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        UserProfile u = items.get(position);
        h.name.setText(u.displayName);
        h.username.setText("@" + u.username);
        Avatars.setInitial(h.avatar, u.displayName);
        boolean checked = selected.contains(u.uid);
        h.ring.setVisibility(checked ? View.VISIBLE : View.GONE);
        h.check.setVisibility(checked ? View.VISIBLE : View.INVISIBLE);
        h.itemView.setOnClickListener(v -> {
            if (!selected.remove(u.uid)) selected.add(u.uid);
            notifyItemChanged(h.getBindingAdapterPosition());
            listener.onSelectionChanged(selected.size());
        });
    }

    @Override
    public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        final TextView avatar, name, username;
        final View ring;
        final ImageView check;
        VH(@NonNull View v) {
            super(v);
            avatar = v.findViewById(R.id.avatar);
            name = v.findViewById(R.id.name);
            username = v.findViewById(R.id.username);
            ring = v.findViewById(R.id.ring);
            check = v.findViewById(R.id.check);
        }
    }
}
