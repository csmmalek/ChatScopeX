package com.chatscopex.app.ui;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.chatscopex.app.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            startActivity(new Intent(this, LauncherActivity.class));
            finish();
            return;
        }
        setContentView(R.layout.activity_main);
        BottomNavigationView nav = findViewById(R.id.bottom_nav);
        nav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            Fragment f;
            if (id == R.id.nav_chats) f = new ChatsFragment();
            else if (id == R.id.nav_status)
                f = PlaceholderFragment.newInstance(R.string.tab_status, R.string.status_coming_soon);
            else if (id == R.id.nav_groups)
                f = PlaceholderFragment.newInstance(R.string.tab_groups, R.string.groups_coming_soon);
            else if (id == R.id.nav_calls)
                f = PlaceholderFragment.newInstance(R.string.tab_calls, R.string.calls_coming_soon);
            else f = new SettingsFragment();
            getSupportFragmentManager().beginTransaction().replace(R.id.container, f).commit();
            return true;
        });
        if (savedInstanceState == null) nav.setSelectedItemId(R.id.nav_chats);
    }
}
