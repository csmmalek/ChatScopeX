package com.chatscopex.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.chatscopex.app.R;
import com.chatscopex.app.model.GroupSummary;
import com.chatscopex.app.util.Avatars;
import com.chatscopex.app.util.ErrorMapper;
import com.chatscopex.app.util.Ui;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;

import java.util.HashSet;
import java.util.Set;

/**
 * Member management. All of this is re-enforced in firestore.rules (a client-side check here is
 * only for UI; a tampered client cannot grant itself admin or edit someone else's membership).
 */
public class GroupInfoActivity extends AppCompatActivity {
    public static final String EXTRA_GROUP_ID = "group_id";

    private String myUid, groupId;
    private FirebaseFirestore db;
    private ListenerRegistration reg;
    private GroupSummary current;
    private MembersAdapter adapter;

    private TextView nameView, avatar;
    private View addMembers, leave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
        groupId = getIntent().getStringExtra(EXTRA_GROUP_ID);
        if (u == null || groupId == null) { finish(); return; }
        myUid = u.getUid();
        db = FirebaseFirestore.getInstance();

        setContentView(R.layout.activity_group_info);
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());
        nameView = findViewById(R.id.name);
        avatar = findViewById(R.id.avatar);
        addMembers = findViewById(R.id.add_members);
        leave = findViewById(R.id.leave);

        RecyclerView list = findViewById(R.id.members_list);
        list.setLayoutManager(new LinearLayoutManager(this));

        leave.setOnClickListener(v -> confirmLeave());
        addMembers.setOnClickListener(v -> Ui.snack(this, R.string.coming_soon)); // simple v1: create-time members only
    }

    @Override
    protected void onStart() {
        super.onStart();
        reg = db.collection("groups").document(groupId).addSnapshotListener((snap, e) -> {
            if (e != null || snap == null || !snap.exists()) {
                if (e != null) Ui.snack(this, ErrorMapper.res(e));
                return;
            }
            current = GroupSummary.from(snap);
            boolean iAmAdmin = current.isAdmin(myUid);
            nameView.setText(current.name);
            Avatars.setInitial(avatar, current.name);
            toolbar().setTitle(current.isChannel() ? R.string.channel_info : R.string.group_info);
            leave.setText(current.isChannel() ? R.string.leave_channel : R.string.leave_group);

            adapter = new MembersAdapter(myUid, iAmAdmin, this::showMenu);
            ((RecyclerView) findViewById(R.id.members_list)).setAdapter(adapter);
            adapter.submit(current.members, new HashSet<>(current.admins));
        });
    }

    private MaterialToolbar toolbar() { return findViewById(R.id.toolbar); }

    @Override
    protected void onStop() {
        super.onStop();
        if (reg != null) { reg.remove(); reg = null; }
    }

    private void showMenu(String uid, View anchor) {
        if (current == null) return;
        PopupMenu menu = new PopupMenu(this, anchor);
        boolean isAdmin = current.admins.contains(uid);
        menu.getMenu().add(0, 1, 0, isAdmin ? R.string.remove_admin : R.string.make_admin);
        menu.getMenu().add(0, 2, 1, R.string.remove_member);
        menu.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == 1) toggleAdmin(uid, !isAdmin);
            else removeMember(uid);
            return true;
        });
        menu.show();
    }

    private void toggleAdmin(String uid, boolean makeAdmin) {
        db.collection("groups").document(groupId)
                .update("admins", makeAdmin ? FieldValue.arrayUnion(uid) : FieldValue.arrayRemove(uid))
                .addOnSuccessListener(v -> Ui.snack(this, R.string.role_updated))
                .addOnFailureListener(e -> Ui.snack(this, ErrorMapper.res(e)));
    }

    private void removeMember(String uid) {
        db.collection("groups").document(groupId).update(
                "members", FieldValue.arrayRemove(uid),
                "admins", FieldValue.arrayRemove(uid)
        ).addOnSuccessListener(v -> Ui.snack(this, R.string.member_removed))
         .addOnFailureListener(e -> Ui.snack(this, ErrorMapper.res(e)));
    }

    private void confirmLeave() {
        new MaterialAlertDialogBuilder(this)
                .setMessage(R.string.confirm_leave)
                .setPositiveButton(R.string.yes_leave, (d, w) -> leaveGroup())
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void leaveGroup() {
        db.collection("groups").document(groupId).update(
                "members", FieldValue.arrayRemove(myUid),
                "admins", FieldValue.arrayRemove(myUid)
        ).addOnSuccessListener(v -> {
            Ui.snack(this, R.string.you_left);
            Intent i = new Intent(this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
        }).addOnFailureListener(e -> Ui.snack(this, ErrorMapper.res(e)));
    }
}
