package com.chatscopex.app.util;

import com.chatscopex.app.R;
import com.google.firebase.FirebaseNetworkException;
import com.google.firebase.FirebaseTooManyRequestsException;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.google.firebase.firestore.FirebaseFirestoreException;

/** Maps Firebase exceptions to localized, user-friendly string resources. Never includes passwords or raw messages. */
public final class ErrorMapper {
    private ErrorMapper() {}

    public static int res(Throwable e) {
        if (e instanceof FirebaseNetworkException) return R.string.err_network;
        if (e instanceof FirebaseTooManyRequestsException) return R.string.err_too_many;
        // WeakPassword extends InvalidCredentials, so it must be checked first.
        if (e instanceof FirebaseAuthWeakPasswordException) return R.string.err_weak_password;
        if (e instanceof FirebaseAuthUserCollisionException) return R.string.err_email_in_use;
        if (e instanceof FirebaseAuthInvalidCredentialsException
                || e instanceof FirebaseAuthInvalidUserException) return R.string.err_auth_credentials;
        if (e instanceof FirebaseFirestoreException) {
            switch (((FirebaseFirestoreException) e).getCode()) {
                case UNAVAILABLE:
                case DEADLINE_EXCEEDED:
                    return R.string.err_network;
                case PERMISSION_DENIED:
                    return R.string.err_permission;
                case UNAUTHENTICATED:
                    return R.string.err_session;
                case FAILED_PRECONDITION:
                    return R.string.err_index;
                default:
                    return R.string.err_unknown;
            }
        }
        return R.string.err_unknown;
    }
}
