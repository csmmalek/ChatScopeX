package com.chatscopex.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.chatscopex.app.R;
import com.chatscopex.app.model.UserProfile;
import com.chatscopex.app.util.ErrorMapper;
import com.chatscopex.app.util.ProfileCache;
import com.chatscopex.app.util.Ui;
import com.google.android.gms.tasks.Tasks;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** Prefix search over usernameLower and displayNameLower (max 20 results each, debounced 400 ms). */
public class UserSearchActivity extends AppCompatActivity {
    private static final int LIMIT = 20;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable pending;
    private int requestId = 0;
    private String myUid;
    private UsersAdapter adapter;
    private TextView hint;
    private ProgressBar progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
        if (u == null) { finish(); return; }
        myUid = u.getUid();

        setContentView(R.layout.activity_user_search);
        ((MaterialToolbar) findViewById(R.id.toolbar)).setNavigationOnClickListener(v -> finish());
        hint = findViewById(R.id.hint);
        progress = findViewById(R.id.progress);
        RecyclerView list = findViewById(R.id.list);
        list.setLayoutManager(new LinearLayoutManager(this));
        adapter = new UsersAdapter(user -> {
            startActivity(new Intent(this, ChatActivity.class)
                    .putExtra(ChatActivity.EXTRA_OTHER_UID, user.uid)
                    .putExtra(ChatActivity.EXTRA_OTHER_NAME, user.displayName));
            finish();
        });
        list.setAdapter(adapter);

        TextInputEditText query = findViewById(R.id.query);
        query.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) {
                if (pending != null) handler.removeCallbacks(pending);
                final String q = s.toString();
                pending = () -> search(q);
                handler.postDelayed(pending, 400);
            }
        });
    }

    private void search(String raw) {
        String n = raw.trim();
        if (n.startsWith("@")) n = n.substring(1);
        n = n.toLowerCase(Locale.ROOT);
        if (n.length() < 2) {
            requestId++;
            progress.setVisibility(View.GONE);
            adapter.submit(new ArrayList<>());
            hint.setText(R.string.search_hint);
            hint.setVisibility(View.VISIBLE);
            return;
        }
        final int rid = ++requestId;
        hint.setVisibility(View.GONE);
        progress.setVisibility(View.VISIBLE);

        FirebaseFirestore db = FirebaseFirestore.getInstance();
        Query byUsername = db.collection("users")
                .whereGreaterThanOrEqualTo("usernameLower", n)
                .whereLessThanOrEqualTo("usernameLower", n + "\uf8ff").limit(LIMIT);
        Query byName = db.collection("users")
                .whereGreaterThanOrEqualTo("displayNameLower", n)
                .whereLessThanOrEqualTo("displayNameLower", n + "\uf8ff").limit(LIMIT);

        Tasks.whenAllSuccess(byUsername.get(), byName.get()).addOnSuccessListener(results -> {
            if (rid != requestId) return; // a newer search superseded this one
            Map<String, UserProfile> merged = new LinkedHashMap<>();
            for (Object o : results) {
                for (DocumentSnapshot d : ((QuerySnapshot) o).getDocuments()) {
                    if (d.getId().equals(myUid)) continue;
                    UserProfile p = UserProfile.from(d);
                    ProfileCache.put(p);
                    merged.put(d.getId(), p);
                }
            }
            progress.setVisibility(View.GONE);
            adapter.submit(new ArrayList<>(merged.values()));
            if (merged.isEmpty()) {
                hint.setText(R.string.search_no_results);
                hint.setVisibility(View.VISIBLE);
            }
        }).addOnFailureListener(e -> {
            if (rid != requestId) return;
            progress.setVisibility(View.GONE);
            Ui.snack(this, ErrorMapper.res(e));
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (pending != null) handler.removeCallbacks(pending);
    }
}
