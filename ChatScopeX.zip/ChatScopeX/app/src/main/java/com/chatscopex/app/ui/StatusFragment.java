package com.chatscopex.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.chatscopex.app.R;
import com.chatscopex.app.model.Status;
import com.chatscopex.app.util.ErrorMapper;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Status list: active (non-expired) statuses from everyone, one row per author (their latest status).
 * The client only hides expired statuses from view; actual deletion needs a Firestore TTL policy on
 * the expiresAt field, set up once in the console (see docs/DATABASE.md) - it is not automatic by itself.
 * Needs the composite index in firestore.indexes.json (expiresAt range + createdAt desc).
 */
public class StatusFragment extends Fragment {
    private String myUid;
    private StatusAdapter adapter;
    private ListenerRegistration reg;
    private ProgressBar progress;
    private TextView empty;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle s) {
        View v = inflater.inflate(R.layout.fragment_status, container, false);
        FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
        myUid = u == null ? "" : u.getUid();

        progress = v.findViewById(R.id.progress);
        empty = v.findViewById(R.id.empty);
        empty.setText(R.string.status_empty);
        RecyclerView list = v.findViewById(R.id.list);
        list.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new StatusAdapter((status, name) -> {
            Intent i = new Intent(requireContext(), StatusViewerActivity.class);
            i.putExtra(StatusViewerActivity.EXTRA_TEXT, status.text);
            i.putExtra(StatusViewerActivity.EXTRA_NAME, name);
            i.putExtra(StatusViewerActivity.EXTRA_TIME, status.createdAtMillis);
            startActivity(i);
        });
        list.setAdapter(adapter);

        FloatingActionButton fab = v.findViewById(R.id.fab);
        fab.setOnClickListener(x -> startActivity(new Intent(requireContext(), PostStatusActivity.class)));
        return v;
    }

    @Override
    public void onStart() {
        super.onStart();
        if (myUid.isEmpty()) return;
        Query q = FirebaseFirestore.getInstance().collection("statuses")
                .whereGreaterThan("expiresAt", new Timestamp(new java.util.Date()))
                .orderBy("expiresAt")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .limit(100);
        reg = q.addSnapshotListener((snap, e) -> {
            if (!isAdded()) return;
            progress.setVisibility(View.GONE);
            if (e != null) {
                empty.setText(ErrorMapper.res(e));
                empty.setVisibility(View.VISIBLE);
                return;
            }
            Map<String, Status> latestByUser = new HashMap<>();
            for (DocumentSnapshot d : snap.getDocuments()) {
                Status st = Status.from(d);
                if (!latestByUser.containsKey(st.uid)) latestByUser.put(st.uid, st); // already ordered newest-first
            }
            List<Status> out = new ArrayList<>(latestByUser.values());
            out.sort((a, b) -> Long.compare(b.createdAtMillis, a.createdAtMillis));
            adapter.submit(out);
            empty.setText(R.string.status_empty);
            empty.setVisibility(out.isEmpty() ? View.VISIBLE : View.GONE);
        });
    }

    @Override
    public void onStop() {
        super.onStop();
        if (reg != null) { reg.remove(); reg = null; }
    }
}
