package com.chatscopex.app.ui;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.chatscopex.app.R;
import com.chatscopex.app.util.TimeFormat;
import com.google.android.material.appbar.MaterialToolbar;

/** Simple full-screen text status viewer. No "seen by" tracking yet. */
public class StatusViewerActivity extends AppCompatActivity {
    public static final String EXTRA_TEXT = "text";
    public static final String EXTRA_NAME = "name";
    public static final String EXTRA_TIME = "time";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status_viewer);
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());
        toolbar.setTitle(getIntent().getStringExtra(EXTRA_NAME));
        ((TextView) findViewById(R.id.text)).setText(getIntent().getStringExtra(EXTRA_TEXT));
        long t = getIntent().getLongExtra(EXTRA_TIME, 0);
        ((TextView) findViewById(R.id.time)).setText(TimeFormat.format(this, t));
    }
}
