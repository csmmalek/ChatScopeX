package com.chatscopex.app.model;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentSnapshot;

import java.util.List;
import java.util.Map;

/** Row in the chat list, built from chats/{chatId}. */
public class ChatSummary {
    public final String chatId;
    public final String otherUid;
    public final String lastText;
    public final String lastSenderId;
    public final long lastTimeMillis;
    public final boolean unread;

    private ChatSummary(String chatId, String otherUid, String lastText, String lastSenderId,
                        long lastTimeMillis, boolean unread) {
        this.chatId = chatId;
        this.otherUid = otherUid;
        this.lastText = lastText;
        this.lastSenderId = lastSenderId;
        this.lastTimeMillis = lastTimeMillis;
        this.unread = unread;
    }

    /** Returns null when the document is malformed (no other member). */
    @SuppressWarnings("unchecked")
    public static ChatSummary from(DocumentSnapshot d, String myUid) {
        Object m = d.get("members");
        if (!(m instanceof List)) return null;
        String other = null;
        for (Object o : (List<Object>) m) {
            if (o instanceof String && !o.equals(myUid)) other = (String) o;
        }
        if (other == null) return null;

        Timestamp ts = d.getTimestamp("lastMessageAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE);
        long last = ts == null ? 0 : ts.toDate().getTime();
        String sender = d.getString("lastMessageSenderId");
        String text = d.getString("lastMessageText");

        long myRead = 0;
        Object lr = d.get("lastRead", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE);
        if (lr instanceof Map) {
            Object v = ((Map<?, ?>) lr).get(myUid);
            if (v instanceof Timestamp) myRead = ((Timestamp) v).toDate().getTime();
        }
        boolean unread = sender != null && !sender.equals(myUid) && myRead < last;
        return new ChatSummary(d.getId(), other, text == null ? "" : text,
                sender == null ? "" : sender, last, unread);
    }
}
