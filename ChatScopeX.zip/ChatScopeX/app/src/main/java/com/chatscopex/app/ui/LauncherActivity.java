package com.chatscopex.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.chatscopex.app.R;
import com.chatscopex.app.util.ErrorMapper;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

/** Routes on app start: signed out -> Login, no profile -> ProfileSetup, otherwise Main. */
public class LauncherActivity extends AppCompatActivity {
    private ProgressBar progress;
    private TextView errorText;
    private Button retry;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launcher);
        progress = findViewById(R.id.progress);
        errorText = findViewById(R.id.error_text);
        retry = findViewById(R.id.retry);
        retry.setOnClickListener(v -> route());
        route();
    }

    private void route() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) {
            go(LoginActivity.class);
            return;
        }
        progress.setVisibility(View.VISIBLE);
        errorText.setVisibility(View.GONE);
        retry.setVisibility(View.GONE);

        FirebaseFirestore.getInstance().collection("users").document(user.getUid()).get()
                .addOnSuccessListener(doc -> go(doc.exists() ? MainActivity.class : ProfileSetupActivity.class))
                .addOnFailureListener(e -> {
                    if (e instanceof FirebaseFirestoreException
                            && ((FirebaseFirestoreException) e).getCode()
                            == FirebaseFirestoreException.Code.UNAUTHENTICATED) {
                        // Session no longer valid (account disabled/deleted, token revoked).
                        FirebaseAuth.getInstance().signOut();
                        go(LoginActivity.class);
                        return;
                    }
                    progress.setVisibility(View.GONE);
                    errorText.setText(ErrorMapper.res(e));
                    errorText.setVisibility(View.VISIBLE);
                    retry.setVisibility(View.VISIBLE);
                });
    }

    private void go(Class<?> target) {
        startActivity(new Intent(this, target));
        finish();
    }
}
