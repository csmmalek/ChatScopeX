package com.chatscopex.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.chatscopex.app.R;
import com.chatscopex.app.model.ChatSummary;
import com.chatscopex.app.util.ErrorMapper;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.List;

/**
 * Chat list. The Firestore listener lives between onStart and onStop so no listener leaks.
 * Needs the composite index in firestore.indexes.json (members array-contains + lastMessageAt desc).
 */
public class ChatsFragment extends Fragment {
    private static final int MAX_CHATS = 50; // first page only; "load more" is a TODO

    private String myUid;
    private ChatsAdapter adapter;
    private ListenerRegistration reg;
    private ProgressBar progress;
    private TextView empty, error;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle s) {
        View v = inflater.inflate(R.layout.fragment_chats, container, false);
        FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
        myUid = u == null ? "" : u.getUid();

        progress = v.findViewById(R.id.progress);
        empty = v.findViewById(R.id.empty);
        error = v.findViewById(R.id.error);
        RecyclerView list = v.findViewById(R.id.list);
        list.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new ChatsAdapter(myUid, (chat, name) -> startActivity(
                new Intent(requireContext(), ChatActivity.class)
                        .putExtra(ChatActivity.EXTRA_OTHER_UID, chat.otherUid)
                        .putExtra(ChatActivity.EXTRA_OTHER_NAME, name)));
        list.setAdapter(adapter);

        FloatingActionButton fab = v.findViewById(R.id.fab);
        fab.setOnClickListener(x -> startActivity(new Intent(requireContext(), UserSearchActivity.class)));
        return v;
    }

    @Override
    public void onStart() {
        super.onStart();
        if (myUid.isEmpty()) return;
        Query q = FirebaseFirestore.getInstance().collection("chats")
                .whereArrayContains("members", myUid)
                .orderBy("lastMessageAt", Query.Direction.DESCENDING)
                .limit(MAX_CHATS);
        reg = q.addSnapshotListener((snap, e) -> {
            if (!isAdded()) return;
            progress.setVisibility(View.GONE);
            if (e != null) {
                error.setText(ErrorMapper.res(e));
                error.setVisibility(View.VISIBLE);
                return;
            }
            error.setVisibility(View.GONE);
            List<ChatSummary> out = new ArrayList<>();
            for (DocumentSnapshot d : snap.getDocuments()) {
                ChatSummary cs = ChatSummary.from(d, myUid);
                if (cs != null) out.add(cs);
            }
            adapter.submit(out);
            empty.setVisibility(out.isEmpty() ? View.VISIBLE : View.GONE);
        });
    }

    @Override
    public void onStop() {
        super.onStop();
        if (reg != null) { reg.remove(); reg = null; }
    }
}
