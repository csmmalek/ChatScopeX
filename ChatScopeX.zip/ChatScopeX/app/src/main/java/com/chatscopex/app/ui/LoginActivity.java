package com.chatscopex.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.chatscopex.app.R;
import com.chatscopex.app.util.ErrorMapper;
import com.chatscopex.app.util.Ui;
import com.chatscopex.app.util.Validators;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;

/** Email/password sign-in, registration and password reset. Passwords are never stored or logged here. */
public class LoginActivity extends AppCompatActivity {
    private boolean registerMode = false;
    private TextInputLayout emailLayout, passLayout;
    private TextInputEditText emailEt, passEt;
    private Button submit, toggle, forgot;
    private ProgressBar progress;
    private TextView subtitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        emailLayout = findViewById(R.id.email_layout);
        passLayout = findViewById(R.id.password_layout);
        emailEt = findViewById(R.id.email);
        passEt = findViewById(R.id.password);
        submit = findViewById(R.id.submit);
        toggle = findViewById(R.id.toggle);
        forgot = findViewById(R.id.forgot);
        progress = findViewById(R.id.progress);
        subtitle = findViewById(R.id.subtitle);

        submit.setOnClickListener(v -> submit());
        toggle.setOnClickListener(v -> { registerMode = !registerMode; render(); });
        forgot.setOnClickListener(v -> resetPassword());
        render();
    }

    private void render() {
        submit.setText(registerMode ? R.string.register : R.string.login);
        toggle.setText(registerMode ? R.string.to_login : R.string.to_register);
        subtitle.setText(registerMode ? R.string.register_subtitle : R.string.login_subtitle);
        forgot.setVisibility(registerMode ? View.GONE : View.VISIBLE);
        emailLayout.setError(null);
        passLayout.setError(null);
    }

    private String email() {
        return emailEt.getText() == null ? "" : emailEt.getText().toString().trim();
    }

    private void setBusy(boolean busy) {
        progress.setVisibility(busy ? View.VISIBLE : View.GONE);
        submit.setEnabled(!busy);
        toggle.setEnabled(!busy);
        forgot.setEnabled(!busy);
    }

    private void submit() {
        emailLayout.setError(null);
        passLayout.setError(null);
        String email = email();
        String pass = passEt.getText() == null ? "" : passEt.getText().toString();

        boolean ok = true;
        if (!Validators.isEmail(email)) {
            emailLayout.setError(getString(R.string.err_email_invalid));
            ok = false;
        }
        if (registerMode ? !Validators.isNewPassword(pass) : pass.isEmpty()) {
            passLayout.setError(getString(registerMode ? R.string.err_password_short : R.string.err_required));
            ok = false;
        }
        if (!ok) return;

        setBusy(true);
        FirebaseAuth auth = FirebaseAuth.getInstance();
        Task<AuthResult> t = registerMode
                ? auth.createUserWithEmailAndPassword(email, pass)
                : auth.signInWithEmailAndPassword(email, pass);
        t.addOnSuccessListener(r -> {
            Intent i = new Intent(this, LauncherActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
            finish();
        }).addOnFailureListener(e -> {
            setBusy(false);
            Ui.snack(this, ErrorMapper.res(e));
        });
    }

    private void resetPassword() {
        emailLayout.setError(null);
        String email = email();
        if (!Validators.isEmail(email)) {
            emailLayout.setError(getString(R.string.err_email_invalid));
            return;
        }
        setBusy(true);
        FirebaseAuth.getInstance().sendPasswordResetEmail(email).addOnCompleteListener(task -> {
            setBusy(false);
            Exception e = task.getException();
            // Same neutral message whether or not the account exists (avoids account enumeration).
            if (task.isSuccessful() || e instanceof FirebaseAuthInvalidUserException) {
                Ui.snack(this, R.string.reset_sent);
            } else {
                Ui.snack(this, ErrorMapper.res(e));
            }
        });
    }
}
