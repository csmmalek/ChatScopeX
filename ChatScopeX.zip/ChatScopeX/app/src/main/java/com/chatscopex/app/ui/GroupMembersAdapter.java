package com.chatscopex.app.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.chatscopex.app.R;
import com.chatscopex.app.model.UserProfile;
import com.chatscopex.app.util.Avatars;
import com.chatscopex.app.util.ProfileCache;

import java.util.ArrayList;
import java.util.List;

/** Member list for GroupInfoActivity. Long-press opens admin actions (handled by the activity). */
public class GroupMembersAdapter extends RecyclerView.Adapter<GroupMembersAdapter.VH> {
    public interface Listener { void onLongPress(String uid, String name); }

    private final List<String> adminUids;
    private final Listener listener;
    private List<String> uids = new ArrayList<>();

    public GroupMembersAdapter(List<String> adminUids, Listener listener) {
        this.adminUids = adminUids;
        this.listener = listener;
    }

    public void submit(List<String> list) {
        uids = list;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_member, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        Context c = h.itemView.getContext();
        String uid = uids.get(position);
        UserProfile p = ProfileCache.peek(uid);
        String name = p != null ? p.displayName : c.getString(R.string.unknown_user);
        h.name.setText(name);
        Avatars.setInitial(h.avatar, name);
        if (p == null) {
            ProfileCache.load(uid, loaded -> {
                int pos = h.getBindingAdapterPosition();
                if (pos != RecyclerView.NO_POSITION && uids.get(pos).equals(uid)) notifyItemChanged(pos);
            });
        }
        boolean admin = adminUids.contains(uid);
        h.badge.setVisibility(admin ? View.VISIBLE : View.GONE);
        h.badge.setText(R.string.admin_badge);
        h.itemView.setOnLongClickListener(v -> {
            listener.onLongPress(uid, name);
            return true;
        });
    }

    @Override
    public int getItemCount() { return uids.size(); }

    static class VH extends RecyclerView.ViewHolder {
        final TextView avatar, name, badge;
        VH(@NonNull View v) {
            super(v);
            avatar = v.findViewById(R.id.avatar);
            name = v.findViewById(R.id.name);
            badge = v.findViewById(R.id.badge);
        }
    }
}
