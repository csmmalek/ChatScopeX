package com.chatscopex.app.model;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentSnapshot;

/** One chat message. "pending" = not yet confirmed by the server; "failed" = rejected, kept locally for retry. */
public class Message {
    public final String id;
    public final String senderId;
    public final String text;
    public final long timeMillis;
    public final boolean pending;
    public final boolean failed;

    public Message(String id, String senderId, String text, long timeMillis, boolean pending, boolean failed) {
        this.id = id;
        this.senderId = senderId;
        this.text = text;
        this.timeMillis = timeMillis;
        this.pending = pending;
        this.failed = failed;
    }

    public static Message from(DocumentSnapshot d) {
        // While the server timestamp is unresolved, ESTIMATE gives a local time so ordering stays stable.
        Timestamp ts = d.getTimestamp("createdAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE);
        long t = ts == null ? System.currentTimeMillis() : ts.toDate().getTime();
        String text = d.getString("text");
        String sender = d.getString("senderId");
        return new Message(d.getId(), sender == null ? "" : sender, text == null ? "" : text,
                t, d.getMetadata().hasPendingWrites(), false);
    }
}
