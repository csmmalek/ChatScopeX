package com.chatscopex.app.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.chatscopex.app.R;
import com.chatscopex.app.model.UserProfile;
import com.chatscopex.app.util.Avatars;

import java.util.ArrayList;
import java.util.List;

public class UsersAdapter extends RecyclerView.Adapter<UsersAdapter.VH> {
    public interface Listener { void onPick(UserProfile user); }

    private final Listener listener;
    private List<UserProfile> items = new ArrayList<>();

    public UsersAdapter(Listener listener) { this.listener = listener; }

    public void submit(List<UserProfile> list) {
        items = list;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_user, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        UserProfile u = items.get(position);
        h.name.setText(u.displayName);
        h.username.setText("@" + u.username);
        Avatars.setInitial(h.avatar, u.displayName);
        h.itemView.setOnClickListener(v -> listener.onPick(u));
    }

    @Override
    public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        final TextView avatar, name, username;

        VH(@NonNull View v) {
            super(v);
            avatar = v.findViewById(R.id.avatar);
            name = v.findViewById(R.id.name);
            username = v.findViewById(R.id.username);
        }
    }
}
