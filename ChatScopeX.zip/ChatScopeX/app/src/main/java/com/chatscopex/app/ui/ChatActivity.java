package com.chatscopex.app.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.chatscopex.app.R;
import com.chatscopex.app.model.Message;
import com.chatscopex.app.util.ChatIds;
import com.chatscopex.app.util.ErrorMapper;
import com.chatscopex.app.util.ProfileCache;
import com.chatscopex.app.util.Ui;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.MetadataChanges;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.firestore.WriteBatch;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * One-to-one chat.
 *  - Messages live in chats/{chatId}/messages/{messageId}; chatId = ChatIds.direct(uidA, uidB).
 *  - The newest PAGE messages are streamed live; older pages are fetched on demand when scrolling up.
 *  - The message id is generated on the client, so a retry rewrites the SAME document (no duplicates).
 *  - Sent/read ticks: "read" = the other member's chats/{chatId}.lastRead[uid] timestamp is >= message time.
 *  - Messages are NOT end-to-end encrypted yet (see README).
 */
public class ChatActivity extends AppCompatActivity {
    public static final String EXTRA_OTHER_UID = "other_uid";
    public static final String EXTRA_OTHER_NAME = "other_name";
    private static final int PAGE = 30;
    private static final int PREVIEW_MAX = 100;

    private FirebaseFirestore db;
    private String myUid, otherUid, chatId;
    private DocumentReference chatRef;

    private RecyclerView list;
    private LinearLayoutManager lm;
    private MessagesAdapter adapter;
    private TextView emptyView;
    private TextInputEditText input;

    /** Confirmed + pending messages by id. REMOVED changes are ignored: rules forbid deleting messages. */
    private final Map<String, Message> all = new HashMap<>();
    /** Messages the server rejected, kept so the user can retry them. */
    private final Map<String, Message> failed = new LinkedHashMap<>();

    private DocumentSnapshot oldest;
    private boolean pageStateKnown = false;
    private boolean hasMore = true;
    private boolean loadingOlder = false;

    private long otherReadMillis = 0;
    private long myReadMillis = 0;
    private long lastMarkedMillis = 0;

    private ListenerRegistration msgReg, chatReg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
        otherUid = getIntent().getStringExtra(EXTRA_OTHER_UID);
        if (u == null || otherUid == null || otherUid.equals(u.getUid())) { finish(); return; }
        myUid = u.getUid();
        chatId = ChatIds.direct(myUid, otherUid);
        db = FirebaseFirestore.getInstance();
        chatRef = db.collection("chats").document(chatId);

        setContentView(R.layout.activity_chat);
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());
        String name = getIntent().getStringExtra(EXTRA_OTHER_NAME);
        if (name != null) toolbar.setTitle(name);
        else ProfileCache.load(otherUid, p -> toolbar.setTitle(p.displayName));

        emptyView = findViewById(R.id.empty);
        input = findViewById(R.id.input);
        list = findViewById(R.id.list);
        lm = new LinearLayoutManager(this);
        lm.setStackFromEnd(true);
        list.setLayoutManager(lm);
        adapter = new MessagesAdapter(myUid, this::retry);
        list.setAdapter(adapter);
        list.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView rv, int dx, int dy) {
                if (dy < 0 && lm.findFirstVisibleItemPosition() <= 2) loadOlder();
            }
        });

        ImageButton send = findViewById(R.id.send);
        send.setOnClickListener(v -> onSendClicked());
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (chatRef == null) return;

        // Live window: newest PAGE messages (including local pending writes).
        Query q = chatRef.collection("messages")
                .orderBy("createdAt", Query.Direction.DESCENDING).limit(PAGE);
        msgReg = q.addSnapshotListener(MetadataChanges.INCLUDE, (snap, e) -> {
            if (e != null) { Ui.snack(this, ErrorMapper.res(e)); return; }
            if (snap == null) return;

            if (!pageStateKnown && !snap.getMetadata().isFromCache()) {
                pageStateKnown = true;
                hasMore = snap.size() >= PAGE;
                List<DocumentSnapshot> docs = snap.getDocuments();
                for (int i = docs.size() - 1; i >= 0; i--) {      // oldest first
                    if (!docs.get(i).getMetadata().hasPendingWrites()) { oldest = docs.get(i); break; }
                }
            }
            for (DocumentChange ch : snap.getDocumentChanges(MetadataChanges.INCLUDE)) {
                if (ch.getType() == DocumentChange.Type.REMOVED) continue;
                DocumentSnapshot d = ch.getDocument();
                all.put(d.getId(), Message.from(d));
                failed.remove(d.getId());
            }
            render(true);
        });

        // Chat document: only used for read receipts (lastRead map).
        chatReg = chatRef.addSnapshotListener((snap, e) -> {
            if (e != null || snap == null) return; // permission/network errors are surfaced by the message listener
            long mine = 0, theirs = 0;
            Object lr = snap.get("lastRead", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE);
            if (lr instanceof Map) {
                Map<?, ?> m = (Map<?, ?>) lr;
                if (m.get(myUid) instanceof Timestamp) mine = ((Timestamp) m.get(myUid)).toDate().getTime();
                if (m.get(otherUid) instanceof Timestamp) theirs = ((Timestamp) m.get(otherUid)).toDate().getTime();
            }
            myReadMillis = mine;
            otherReadMillis = theirs;
            render(false);
        });
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (msgReg != null) { msgReg.remove(); msgReg = null; }
        if (chatReg != null) { chatReg.remove(); chatReg = null; }
    }

    // ------------------------------------------------------------------ rendering

    private void render(boolean allowAutoScroll) {
        List<Message> out = new ArrayList<>(all.values());
        out.addAll(failed.values());
        Collections.sort(out, (a, b) -> {
            int c = Long.compare(a.timeMillis, b.timeMillis);
            return c != 0 ? c : a.id.compareTo(b.id);
        });

        boolean nearBottom = lm.findLastVisibleItemPosition() >= adapter.getItemCount() - 2;
        boolean lastIsMine = !out.isEmpty() && out.get(out.size() - 1).senderId.equals(myUid);
        adapter.submit(out, otherReadMillis);
        if (allowAutoScroll && !out.isEmpty() && (nearBottom || lastIsMine)) {
            list.scrollToPosition(out.size() - 1);
        }
        emptyView.setVisibility(out.isEmpty() ? View.VISIBLE : View.GONE);
        markReadIfNeeded(out);
    }

    /** Writes lastRead[myUid] when there is a confirmed incoming message newer than my last read marker. */
    private void markReadIfNeeded(List<Message> sorted) {
        long newestIncoming = 0;
        for (Message m : sorted) {
            if (!m.senderId.equals(myUid) && !m.pending && m.timeMillis > newestIncoming) newestIncoming = m.timeMillis;
        }
        if (newestIncoming > myReadMillis && newestIncoming > lastMarkedMillis) {
            lastMarkedMillis = newestIncoming;
            // update() fails with NOT_FOUND if the chat doc doesn't exist yet; that is harmless here.
            chatRef.update("lastRead." + myUid, FieldValue.serverTimestamp());
        }
    }

    // ------------------------------------------------------------------ paging

    private void loadOlder() {
        if (loadingOlder || !hasMore || oldest == null) return;
        loadingOlder = true;
        chatRef.collection("messages")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .startAfter(oldest).limit(PAGE).get()
                .addOnSuccessListener(qs -> {
                    loadingOlder = false;
                    int before = all.size();
                    List<DocumentSnapshot> docs = qs.getDocuments();
                    for (DocumentSnapshot d : docs) all.put(d.getId(), Message.from(d));
                    if (!docs.isEmpty()) oldest = docs.get(docs.size() - 1);
                    hasMore = docs.size() >= PAGE;
                    int added = all.size() - before;
                    render(false);
                    if (added > 0) lm.scrollToPositionWithOffset(added, 0); // keep the reader's place
                })
                .addOnFailureListener(e -> {
                    loadingOlder = false;
                    Ui.snack(this, ErrorMapper.res(e));
                });
    }

    // ------------------------------------------------------------------ sending

    private void onSendClicked() {
        String text = input.getText() == null ? "" : input.getText().toString().trim();
        if (text.isEmpty()) return;
        input.setText("");
        String id = chatRef.collection("messages").document().getId(); // client-generated => idempotent retry
        send(id, text, System.currentTimeMillis());
    }

    private void retry(Message m) {
        failed.remove(m.id);
        render(false);
        send(m.id, m.text, m.timeMillis);
    }

    private void send(String id, String text, long localTime) {
        DocumentReference msgRef = chatRef.collection("messages").document(id);

        Map<String, Object> msg = new HashMap<>();
        msg.put("senderId", myUid);
        msg.put("text", text);
        msg.put("type", "text");
        msg.put("createdAt", FieldValue.serverTimestamp());

        // Merge-set: creates the chat on the first message, otherwise only updates the "last message" fields.
        // (members/type are identical on later writes, which the security rules require.)
        Map<String, Object> chat = new HashMap<>();
        chat.put("members", Arrays.asList(myUid.compareTo(otherUid) < 0
                ? new String[]{myUid, otherUid} : new String[]{otherUid, myUid}));
        chat.put("type", "direct");
        chat.put("lastMessageText", text.length() > PREVIEW_MAX ? text.substring(0, PREVIEW_MAX) : text);
        chat.put("lastMessageSenderId", myUid);
        chat.put("lastMessageAt", FieldValue.serverTimestamp());

        WriteBatch b = db.batch();
        b.set(chatRef, chat, SetOptions.merge());
        b.set(msgRef, msg);
        // While offline the batch stays queued and the message shows as pending (clock icon).
        b.commit().addOnFailureListener(e -> {
            all.remove(id);
            failed.put(id, new Message(id, myUid, text, localTime, false, true));
            render(true);
            Ui.snack(this, ErrorMapper.res(e));
        });
    }
}
